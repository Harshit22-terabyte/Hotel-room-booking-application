package com.sweet.home.service;

import com.sweet.home.model.BookingInfoEntity;
import com.sweet.home.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookingService {

    private final BookingRepository bookingRepository;

    @Autowired
    public BookingService(BookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    public BookingInfoEntity saveBooking(BookingInfoEntity bookingInfo) {
        return bookingRepository.save(bookingInfo);
    }

    public BookingInfoEntity getBookingById(int bookingId) {
        return bookingRepository.findById(bookingId).orElse(null);
    }

    public boolean updateBookingWithTransactionId(int bookingId, int transactionId) {
        // Implement the logic to update the booking with the transaction ID
        BookingInfoEntity booking = bookingRepository.findById(bookingId).orElse(null);
        if (booking != null) {
            booking.setTransactionId(transactionId);
            bookingRepository.save(booking);
            return true;
        }
        return false;
    }
}
