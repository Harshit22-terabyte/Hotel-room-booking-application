package com.sweet.home.services;

import com.sweet.home.dto.TransactionDetailsRequest;
import com.sweet.home.model.TransactionDetailsEntity;

public interface TransactionService {

    String performTransaction(TransactionDetailsRequest request);

    void saveTransactionDetails(TransactionDetailsRequest request, String transactionId);

    TransactionDetailsEntity getTransactionDetails(int transactionId);
}
